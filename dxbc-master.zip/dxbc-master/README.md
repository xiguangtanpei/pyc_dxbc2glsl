## Resources

* [Parsing Direct3D Shader Bytecode](http://timjones.io/blog/archive/2015/09/02/parsing-direct3d-shader-bytecode)
* [List of all SM5 instructions](https://docs.microsoft.com/en-us/windows/desktop/direct3dhlsl/shader-model-5-assembly--directx-hlsl-)
