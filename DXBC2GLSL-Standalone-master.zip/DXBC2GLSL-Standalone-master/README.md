# DXBC2GLSL-Standalone
Standalone version of KlayGE's DXBC2GLSL from https://github.com/QiangJi/Klay-GE