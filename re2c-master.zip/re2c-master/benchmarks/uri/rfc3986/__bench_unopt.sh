
. ../../__bench_utils.sh

compile uri rfc3986 "--no-optimize-tags"
run_all uri rfc3986

