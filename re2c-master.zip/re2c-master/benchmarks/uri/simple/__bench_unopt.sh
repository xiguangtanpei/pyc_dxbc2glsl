
. ../../__bench_utils.sh

compile uri simple "--no-optimize-tags"
run_all uri simple

