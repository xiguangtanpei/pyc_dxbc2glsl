
. ../../__bench_utils.sh

compile uri simple ""
run_all uri simple

