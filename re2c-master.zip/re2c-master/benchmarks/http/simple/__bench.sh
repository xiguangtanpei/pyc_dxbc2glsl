
. ../../__bench_utils.sh

compile http simple ""
run_all http simple

