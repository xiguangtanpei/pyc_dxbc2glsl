
. ../../__bench_utils.sh

compile http simple "--no-optimize-tags"
run_all http simple

