american_fuzzy_lop/003.re:2:8: error: unexpected end of input
