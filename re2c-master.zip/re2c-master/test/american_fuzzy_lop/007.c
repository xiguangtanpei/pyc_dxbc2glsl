american_fuzzy_lop/007.re:3:18: error: missing ending ';' in configuration
