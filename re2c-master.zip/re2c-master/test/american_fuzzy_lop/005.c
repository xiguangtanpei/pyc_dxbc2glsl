american_fuzzy_lop/005.re:2:8: error: syntax error in escape sequence
