conditions/cond_error_12.re:4:4: error: syntax error in condition list
