conditions/cond_error_09.re:7:5: error: code to setup rule 'a' is already defined at line 6
