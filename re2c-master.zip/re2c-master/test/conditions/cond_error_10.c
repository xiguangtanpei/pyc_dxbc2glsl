conditions/cond_error_10.re:7:5: error: setup for non existing condition 'c' found
