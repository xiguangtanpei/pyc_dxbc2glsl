conditions/cond_error_08.re:5:3: error: startup code is already defined at line 4
