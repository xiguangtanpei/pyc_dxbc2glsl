conditions/cond_error_11.re:8:5: error: setup for all conditions '<!*>' is illegal if setup for each condition is defined explicitly
