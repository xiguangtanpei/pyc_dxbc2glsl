conditions/cond_error_07.re:4:4: error: syntax error in condition list
